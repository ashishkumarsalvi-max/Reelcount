# Reel Counter

A tiny, open-source, privacy-first Android app that counts the Reels / Shorts
you scroll in Instagram, YouTube and Facebook, shows a "brain" that degrades as
the count rises, and can stop you at a daily limit.

## Why you can trust it

- **No `INTERNET` permission.** Check `app/src/main/AndroidManifest.xml`. Without it Android will not let the app send data anywhere.
- **No dependencies.** `app/build.gradle.kts` has none, so there is no third-party SDK to audit.
- **Only three apps are visible to it.** The accessibility service is limited to `com.instagram.android`, `com.google.android.youtube` and `com.facebook.katana` in `res/xml/accessibility_config.xml`. The OS enforces this.
- **It never reads text.** It only checks view IDs to see whether a Reels screen is open.
- **Stores one number per day**, in local SharedPreferences. `allowBackup` is off.

## Build

1. Open this folder in Android Studio (Koala or newer) and let it sync. It downloads Gradle 8.7 from `gradle/wrapper/gradle-wrapper.properties`.
2. Run on a device or build an APK: **Build > Build APK(s)**.
   (Command line: run `gradle wrapper` once, then `./gradlew assembleDebug`.)

## First run

1. Open the app, tap **Open accessibility settings**, and enable **Reel Counter**.
2. On Android 13+ a sideloaded app may show the toggle greyed out. Go to
   **Settings > Apps > Reel Counter > ⋮ > Allow restricted settings**, then try again.
3. Open Instagram Reels or YouTube Shorts and swipe. The count should go up.

## IMPORTANT: view IDs need verifying

Detection relies on view-ID fragments in `TARGETS`
(`ReelAccessibilityService.kt`). They are best-effort guesses and these apps
change their layouts often. If nothing counts:

```
adb shell uiautomator dump /sdcard/ui.xml && adb pull /sdcard/ui.xml
```

Run it while a reel is on screen, search `ui.xml` for `resource-id`, and put a
fragment unique to the Reels screen into `TARGETS`. Android Studio's Layout
Inspector also works. Tune `NEW_SWIPE_GAP_MS` / `MIN_COUNT_INTERVAL_MS` if counts are
too high or low.

## Ideas

- Room database and charts
- A task or timer before unlocking after the limit
- Snapchat support
- Optional, separate, opt-in module for friend battles

License: MIT
