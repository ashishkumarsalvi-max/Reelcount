package dev.reelcount

import android.animation.ArgbEvaluator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/** A face that starts healthy and green, and rots as [damage] goes from 0 to 1. */
class BrainView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var damage: Float = 0f
        set(value) {
            field = value.coerceIn(0f, 1f)
            invalidate()
        }

    private val evaluator = ArgbEvaluator()
    private val healthy = Color.parseColor("#4CAF50")
    private val rotten = Color.parseColor("#B71C1C")
    private val ink = Color.parseColor("#222222")

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink }
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 8f
        strokeCap = Paint.Cap.ROUND
        color = ink
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) * 0.42f

        fill.color = evaluator.evaluate(damage, healthy, rotten) as Int
        canvas.drawCircle(cx, cy, r, fill)

        // Eyes: dots when okay, X's when badly damaged.
        val ex = r * 0.38f
        val ey = cy - r * 0.2f
        if (damage > 0.7f) {
            for (side in listOf(-1f, 1f)) {
                val x = cx + side * ex
                canvas.drawLine(x - 14f, ey - 14f, x + 14f, ey + 14f, line)
                canvas.drawLine(x - 14f, ey + 14f, x + 14f, ey - 14f, line)
            }
        } else {
            canvas.drawCircle(cx - ex, ey, 12f, dot)
            canvas.drawCircle(cx + ex, ey, 12f, dot)
        }

        // Mouth: smile -> flat -> frown.
        val my = cy + r * 0.38f
        path.reset()
        path.moveTo(cx - r * 0.4f, my)
        path.quadTo(cx, my + r * 0.35f * (1f - 2f * damage), cx + r * 0.4f, my)
        canvas.drawPath(path, line)

        // Cracks.
        if (damage > 0.4f) {
            path.reset()
            path.moveTo(cx + r * 0.10f, cy - r)
            path.lineTo(cx - r * 0.05f, cy - r * 0.72f)
            path.lineTo(cx + r * 0.12f, cy - r * 0.52f)
            path.lineTo(cx, cy - r * 0.32f)
            canvas.drawPath(path, line)
        }
        if (damage > 0.7f) {
            path.reset()
            path.moveTo(cx - r * 0.60f, cy + r * 0.80f)
            path.lineTo(cx - r * 0.45f, cy + r * 0.55f)
            path.lineTo(cx - r * 0.62f, cy + r * 0.40f)
            canvas.drawPath(path, line)
        }
    }
}
