package dev.reelcount

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast

/**
 * Counts reels by watching scroll events inside the short-video screen of a few apps.
 *
 * Privacy: the OS only delivers events from the packages listed in
 * res/xml/accessibility_config.xml, and this class never reads text, only view IDs.
 */
class ReelAccessibilityService : AccessibilityService() {

    private lateinit var store: Store

    private var lastScrollAt = 0L
    private var lastCountAt = 0L
    private var lastBlockAt = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = Store(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val markers = TARGETS[event.packageName?.toString()] ?: return
        val now = SystemClock.elapsedRealtime()

        when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // One swipe fires many scroll events; only the first of a burst counts.
                val gap = now - lastScrollAt
                lastScrollAt = now
                if (gap < NEW_SWIPE_GAP_MS) return
                if (now - lastCountAt < MIN_COUNT_INTERVAL_MS) return
                if (!isInReels(markers)) return

                val limit = store.limit
                if (limit > 0 && store.today() >= limit) {
                    block(now)
                    return
                }
                lastCountAt = now
                store.increment()
            }

            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                // Stop the user from re-entering reels after the limit is reached.
                val limit = store.limit
                if (limit > 0 && store.today() >= limit && isInReels(markers)) block(now)
            }
        }
    }

    private fun block(now: Long) {
        if (now - lastBlockAt < BLOCK_COOLDOWN_MS) return
        lastBlockAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
        Toast.makeText(this, "Daily reel limit reached", Toast.LENGTH_SHORT).show()
    }

    /** Breadth-first search of the active window for a view ID that matches a reels marker. */
    private fun isInReels(markers: List<String>): Boolean {
        val root = rootInActiveWindow ?: return false
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < MAX_NODES) {
            val node = queue.removeFirst()
            visited++
            val id = node.viewIdResourceName
            if (id != null && markers.any { id.contains(it, ignoreCase = true) }) return true
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.add(it) }
        }
        return false
    }

    override fun onInterrupt() = Unit

    companion object {
        private const val NEW_SWIPE_GAP_MS = 350L
        private const val MIN_COUNT_INTERVAL_MS = 600L
        private const val BLOCK_COOLDOWN_MS = 1500L
        private const val MAX_NODES = 400

        /**
         * package -> substrings of view IDs that exist only on the Reels/Shorts screen.
         *
         * THESE ARE BEST-EFFORT and WILL BREAK when the apps update. Verify with:
         *   adb shell uiautomator dump /sdcard/ui.xml && adb pull /sdcard/ui.xml
         * (run while a reel is on screen, then search the file for "resource-id"),
         * or Android Studio > Layout Inspector. Edit this table to match.
         */
        private val TARGETS: Map<String, List<String>> = mapOf(
            "com.instagram.android" to listOf("clips_viewer", "clips_swipe_refresh"),
            "com.google.android.youtube" to listOf("reel_recycler", "reel_player_page"),
            "com.facebook.katana" to listOf("reels_viewer", "reel_viewer")
        )
    }
}
