package dev.reelcount

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import java.time.format.TextStyle
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var store: Store
    private lateinit var brain: BrainView
    private lateinit var count: TextView
    private lateinit var status: TextView
    private lateinit var history: TextView
    private lateinit var limitInput: EditText

    // Counts are written by the accessibility service; refresh the UI live.
    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        runOnUiThread { refresh() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        store = Store(this)
        brain = findViewById(R.id.brain)
        count = findViewById(R.id.count)
        status = findViewById(R.id.status)
        history = findViewById(R.id.history)
        limitInput = findViewById(R.id.limitInput)

        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            store.limit = limitInput.text.toString().toIntOrNull() ?: 0
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            refresh()
        }

        limitInput.setText(if (store.limit > 0) store.limit.toString() else "")
    }

    override fun onStart() {
        super.onStart()
        store.register(prefsListener)
        refresh()
    }

    override fun onStop() {
        store.unregister(prefsListener)
        super.onStop()
    }

    private fun refresh() {
        val today = store.today()
        val limit = store.limit
        count.text = today.toString()
        brain.damage = today / (if (limit > 0) limit else DEFAULT_SCALE).toFloat()

        status.text = if (isServiceEnabled()) {
            "Tracking is ON"
        } else {
            "Tracking is OFF. Turn on \"Reel Counter\" in Accessibility settings."
        }

        history.text = store.history().joinToString("\n") { (day, n) ->
            val name = day.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale.getDefault())
            "$name ${day.dayOfMonth}/${day.monthValue}: $n"
        }
    }

    private fun isServiceEnabled(): Boolean {
        val me = ComponentName(this, ReelAccessibilityService::class.java).flattenToString()
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.split(':').any { it.equals(me, ignoreCase = true) }
    }

    companion object {
        /** Reel count at which the brain is fully "gone" when no limit is set. */
        private const val DEFAULT_SCALE = 200
    }
}
