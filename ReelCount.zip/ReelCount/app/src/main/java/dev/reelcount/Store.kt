package dev.reelcount

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

/** Local-only storage: one integer per day plus the daily limit. */
class Store(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("reelcount", Context.MODE_PRIVATE)

    private fun key(day: LocalDate) = "count_$day"

    fun today(): Int = prefs.getInt(key(LocalDate.now()), 0)

    fun increment(): Int {
        val next = today() + 1
        prefs.edit().putInt(key(LocalDate.now()), next).apply()
        return next
    }

    var limit: Int
        get() = prefs.getInt("limit", 0)
        set(value) = prefs.edit().putInt("limit", value.coerceAtLeast(0)).apply()

    fun history(days: Int = 7): List<Pair<LocalDate, Int>> =
        (0 until days).map { offset ->
            val day = LocalDate.now().minusDays(offset.toLong())
            day to prefs.getInt(key(day), 0)
        }

    fun register(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.registerOnSharedPreferenceChangeListener(listener)

    fun unregister(listener: SharedPreferences.OnSharedPreferenceChangeListener) =
        prefs.unregisterOnSharedPreferenceChangeListener(listener)
}
